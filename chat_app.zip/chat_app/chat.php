<?php
    session_start();
    require('connect.php');
    // require('../pages/doctor/header_authentication.php');
    // require('../pages/pages_header.php');
    

    $username_to = "<script>document.writeln(username_to);</script>";

    // $email = $_GET['email'];

    // $username = $_SESSION['username'];
    $sql = "SELECT * FROM doctor_signup WHERE Username != '$username' AND Online_Status = 'Online';";
    $result=mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($result);
    $chcek = mysqli_num_rows($result);

?>
<!-- <script type="text/javascript">
    var username = localStorage.getItem('new_username');
    
</script> -->
    <!-- <title> </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script type="" src='https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js'></script> 
    <script type="" src='https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js'>
    </script> -->
    <script type="text/javascript">
    var username_to = localStorage.getItem('new_username');
    </script>
    <script type="">
        function submit_chat(){

             var uname_to = username_to;
            if(form1.uname.value=='' || form1.msg.value ==''){
                // alert('ALL FIELDS ARE MANDETORY');
                return;
            }
            var uname = form1.uname.value;
            var msg = form1.msg.value;

            var xmlhttp = new XMLHttpRequest()

            xmlhttp.onload = function(){
                if(xmlhttp.status ==200){
                    document.getElementById('chat_logs').innerHTML = xmlhttp.responseText;
                    document.getElementById('msg').value='';
                }
            }
            xmlhttp.open('GET','insert.php?uname_to='+uname_to +'&uname='+uname +'&msg='+msg, true);
            xmlhttp.send();         
        
        }

       // var  start_scroller = setInterval(start_scroll, 1000);

       //  function start_scroll(){
       //      var chat_logs = document.getElementById('chat_logs');
       //      chat_logs.scrollTop = chat_logs.scrollHeight;
            
       //      // alert(chat_logs.scrollHeight);
            
       //  }
    </script>


<body onclick="stop_scroll()">
        <div style="width: 500px; margin-left:auto; margin-right:auto;margin-top:70px">
        <a href = 'doctor_profile.php?username=<script>writeln($username_to)</script>'><div style="background: #345467; color:#EEE; font-size:20px; width: 100%;height:50px; text-align:   center "><?php echo $username_to?></div></a>
        <div id='chat_logs' ></div>
        <form name='form1'>      
            <input type="hidden" name="uname" value=<?php echo $_SESSION['username'] ?>>
            <textarea name="msg" id='msg'  style='width:500px; height: auto: max-height: 500px; min-height: 200px; background: #EEE' placeholder="Type Message..." ></textarea><br>
            <a href="#" onclick="submit_chat(); scroll(); start_scroll()" id = 'send_msg' class='btn btn-success' style='width:40%; margin-left:60%'>Send Message</a>
        </form>
        
        </div>
</body>
</html>
    <script type="">
        $(document).ready(function(e){
        
         // let old_scrollHeight = document.getElementById('chat_logs');
        var uname_to = username_to;

        $.ajaxSetup({cache:false});
        setInterval(function(){

            var xmlhttp2 = new XMLHttpRequest()

                xmlhttp2.onload = function(){
                    if(xmlhttp2.status ==200){
                        document.getElementById('chat_logs').innerHTML = xmlhttp2.responseText;
                           $("#chat_logs").animate({ scrollTop: new_scrollHeight}, 'normal'); 
                    }
                }
                xmlhttp2.open('GET','logs.php?uname_to='+uname_to, true);
                xmlhttp2.send();

        }, 1);
            
                           
                
            
            
        })
        
                 function scroll(){
                    // var chat_logs = document.getElementById('chat_logs');
                    // chat_logs.scrollTop = chat_logs.scrollHeight;
                 }
                 
                 
                 // var scroller = setInterval(scroll,1000);
                 var start_scroller = setInterval(start_scroll,1000);
                 
                 function stop_scroll(){
                    // clearInterval(scroller);
                    clearInterval(start_scroller);
                 }
        
                 function start_scroll(){
                    var chat_logs = document.getElementById('chat_logs');
                    var new_scrollHeight   = chat_logs.scrollHeight ;
                    $("#chat_logs").animate({ scrollTop: new_scrollHeight}, 'normal'); 
                 }
        
            // $("#chat_logs").animate({ scrollTop: newscrollHeight }, 'normal'); 
        
        
        
    </script>
<style type="">
    #chat_logs{
        height: 40vh;
        overflow:  auto;
        position:  relative;   
        border-bottom:1px solid darkgray;
        /*-moz-transform: rotate(180deg);
    -webkit-transform: rotate(180deg);
    -ms-transform: rotate(180deg);
    -o-transform: rotate(180deg);
    transform: rotate(180deg);*/
    }
    
</style>