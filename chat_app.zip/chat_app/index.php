<!DOCTYPE html>
<html>
<head>
    <title></title>

    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script type="text/javascript" src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js'></script>

    <style type="">
        .chat_container{
            position: ;
        }
        .card h6{
            background: #434546;
            padding: 1em ;
            color: white;
        }
        .chat_box_1{
        grid-row: 1;
        grid-column:1; 
        height: 450px; 
        width: 350px;
        display: none;
        position:  absolute;   
        bottom:100px;
        right: 1em;
        background: 
    }
    .chat_box_1 form{
        padding: 20px;
    }
    .button{
        position: absolute;
        bottom: 1em;
        right: 1em;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #354654;
        color:#DDD;
        text-align: center;
        cursor: pointer;
    }
    button:hover{
        background: #234576
        box-shadow: 2px 3px 3px gray;
        cursor: pointer;
    }
    #name_label{
        display: block;
        transition: all 3s
    }
    .text_area{
        margin-top: 4em;
        height: 20em;
        width: 100%;
    }
    .send_msg{
        margin-top: 2em;
        float:right;
    }
    #chat_box_2{
        display: none
    }
    .main_chart{
        display:   none;   
        height: 250px;
        background: #DDD
    }
    .intro_form{
        height: 250px;
        box-sizing:    border-box; 
        
    }
    </style>
</head>
<body>
    
    <div>
          <div style=""  id='show_box' class="button"><i class="fas fa-comments fa-2x " style="color:#0311C4;" ></i>CHAT</div>


             <div class='card chat_box_1' style="" id='chat_box_1'>
                <h6>Chat Now</h6>
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>">
                    <div class='intro_form' id='intro_form'>
                        <div id='name_label'>Name</div>
                        <input type="text" name="name"  id='name' placeholder="" class="chat_imput form-control" id='name' oninput = 'show_label()'>
                        <div id='email_label'>Email</div>
                        <input type="text" name="email" id = 'email' placeholder="" id='email' class="chat_imput form-control">
                        <div id = 'display_chats'></div>
                        <textarea class='text_area form-control' placeholder="Write your message" id='msg' id='msg'></textarea>
                    </div>
                    <div class='main_chart' id="main_chart">
                        
                    </div>
                    <input type="button" name="submit_chat" value='Send Message' class ='btn btn-info send_msg' onclick='chat_send()'>
                    <!-- <button type='submit' name='submit_chat_search'>SEARCH</button> -->
                </form>

              
              

                                <!-- SCRIPT TO DISPLAY CHAT POP-UP -->
                             <!--  <script type="text/javascript">

                                        function show_chats(x){
                                                var username = x.name;
                                                // var name = x.value;

                                                localStorage.setItem('new_username', username);

                                            $.get("chat/index.php",
                                              {
                                                Username_to: 'username',
                                                
                                                // city: "Duckburg"
                                              },
                                              function(data, status){
                                                // alert(username)
                                                 window.open("chat/index.php","_blank", "toolbar=yes,scrollbars=yes,resizable=no,top=100,left=500,width=540,height=750")
                                              });

                                     
                                    }
                                     </script> -->
                                   
                          
                        </div>

    </div>
<script type="">
    $('#show_box').click(function(){
    $('.chat_box_1').slideToggle('slow');
})

    function chat_send(){
        
       var name = $('#name').val();
       var email = $('#email').val();
       var msg = $('#msg').val();
       var query_string = "name=" + name + "&email="+email + "&msg="+ msg;    
        if(name=='' || email ==''){
            return;
        }

        var xmlhttp = new XMLHttpRequest()

        xmlhttp.onload = function(){
            if(xmlhttp.status ==200){
                document.getElementById('intro_form').style.display = 'none';
                document.getElementById('main_chart').style.display = 'block';
                document.getElementById('main_chart').innerHTML = this.responseText;
                
            }
        }

      
        xmlhttp.open('GET',"insert_chat.php?name=" + name + "&email="+email + "&msg="+ msg, true);
        xmlhttp.send(); 
    }
</script>
</body>
</html>

 