<?php
    
        session_start();
        
        $name = $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $msg = $_REQUEST['msg'];
        $input_string = $name.'|'.$email.'|'. $msg;
        $input_ser =  serialize($input_string);
        // .';'."\n"
        date_default_timezone_set('Africa/Lagos');
        $date = Date('Y-m-d');
        $time = date('h:i:sa',time());

        $today = date('Y-m-d');
        $today_2 = strtotime($today);

        $file_w  =fopen('chat_log.txt', "a");        
        fwrite($file_w, $input_ser);
        fclose($file_w);
    
        // $input_string = array("name"=>$name, "email"=>$email, ""=>"43")

        $file_r = fopen('chat_log.txt', 'r');

        while(!feof($file_r)){
                $data = fgets($file_r);
                $data_items[] = explode(";",$data);
                foreach ($data_items as $key => $value){
                $data_items_2[] = explode("|",$data);
                        foreach ($data_items_2 as $item){
                                
                        print_r($item[0]);
                        echo "<br>";
                                
                        }
                }
                // list($name,$email,$msg) = $data_items;

                // print_r($data_items);
                
        }





      // echo "<div style='background: white; padding: 10px; width: 90%; border-radius: 10px; margin: 5px;'>";
      //   echo "<div>" .$name ."</div>";
      //   echo "<div>" .$msg ."</div>";
      //   echo "</div>";
?>